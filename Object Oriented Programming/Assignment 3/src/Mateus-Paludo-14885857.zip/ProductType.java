/**
 * COMP503 Programming 2 Assignment 3 2016 S1
 *
 * This class is an enum class
 * It enumarates the product styles
 *  
 * @author  Mateus Felipe Paludo - 14885857
 * @version 1.0 - 30.05.2016: Created
 */

public enum ProductType
{
	BOOK, GAME, CONSOLE;
}
